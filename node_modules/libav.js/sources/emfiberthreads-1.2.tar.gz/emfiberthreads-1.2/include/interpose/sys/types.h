#ifndef EMFIBERTHREADS_SYS_TYPES_H
#define EMFIBERTHREADS_SYS_TYPES_H 1

#include "../pthread.h"
#include_next<sys/types.h>

#endif

#ifndef EMFIBERTHREADS_SIGNAL_H
#define EMFIBERTHREADS_SIGNAL_H 1

#include "pthread.h"
#include_next<signal.h>

#endif

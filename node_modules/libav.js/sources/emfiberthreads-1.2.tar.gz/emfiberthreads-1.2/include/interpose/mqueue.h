#ifndef EMFIBERTHREADS_MQUEUE_H
#define EMFIBERTHREADS_MQUEUE_H 1

#include "pthread.h"
#include_next<mqueue.h>

#endif

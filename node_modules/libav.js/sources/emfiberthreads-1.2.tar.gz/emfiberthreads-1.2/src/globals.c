#include "pthread-internal.h"
struct emfiberthreads_pthread_t emfiberthreads_mainFiber;
emfiber_pthread_t emfiberthreads_self;
emfiber_pthread_t emfiberthreads_next;

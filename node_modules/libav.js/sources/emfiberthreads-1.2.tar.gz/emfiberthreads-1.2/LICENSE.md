0BSD. This library does not require attribution.

The license text for this code is in the source files.
[LICENSE files do more harm than good](https://yahweasel.github.io/license-files-considered-harmful/).

This file exists because some people expect it to be here.
